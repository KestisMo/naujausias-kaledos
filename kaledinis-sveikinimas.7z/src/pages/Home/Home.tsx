import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Loader from '../../components/Loader/Loader';
import styled, { keyframes } from 'styled-components';

const blink = keyframes`
  0%, 100% {
    opacity: 1;
  }
  50% {
    opacity: 0.8;
  }
`;

const sparkle = keyframes`
  0% {
    transform: scale(1);
  }
  50% {
    transform: scale(1.2);
  }
  100% {
    transform: scale(1);
  }
`;

const StyledButton = styled.button`
  height: 400px;
  width: 400px;
  font-size: 32px;
  background: linear-gradient(to right, #004d00, #006400);
  color: #fff;
  border: none;
  border-radius: 50%;
  cursor: pointer;
  outline: none;
  transition: background 0.3s ease, transform 0.3s ease;
  animation: ${blink} 1s infinite;

  &:hover {
    animation: ${sparkle} 0.5s infinite;
  }
`;

const containerStyle: React.CSSProperties = {
  width: '100%',
  height: '100vh',
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', // Increase the minimum size of the grid cells
  gridAutoRows: '200px', // Increase the height of the grid rows
  color: 'white',
  fontSize: '2em',
  textShadow: '2px 2px 4px rgba(0, 0, 0, 0.5)',
  position: 'relative',
  overflow: 'hidden',
};

const gifStyle: React.CSSProperties = {
  width: '100%',
  height: '100%',
  backgroundSize: 'cover',
  backgroundRepeat: 'no-repeat',
};

const contentStyle: React.CSSProperties = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  zIndex: 2, // Set a higher z-index value
};

const AppWrapper = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100vh;
  background: linear-gradient(to right, rgba(0, 66, 0, 0.5), rgba(0, 100, 0, 0.7));
`;


interface GifData {
  images: {
    original: {
      url: string;
    };
  };
}

const Home: React.FC = () => {
  const [gifUrls, setGifUrls] = useState<string[]>([]);
  const [currentGifIndexes, setCurrentGifIndexes] = useState<number[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [countdown, setCountdown] = useState(0);

  useEffect(() => {
    const fetchRandomGifs = async () => {
      try {
        const apiKey = '8fJKn6mPOa42FNFWkbh8nVVprZpnGZ6P';
        const numGifs = 300;
        const apiUrl = `https://api.giphy.com/v1/gifs/search?api_key=${apiKey}&q=christmas&limit=${numGifs}`;
    
        const response = await axios.get(apiUrl);
        const gifDataArray: GifData[] = response.data.data;
    
        // Initialize an empty array for storing valid URLs
        const validGifUrls: string[] = [];
    
        // Use Promise.all to wait for all requests to complete
        await Promise.all(gifDataArray.map(async (gifData) => {
          const gifUrl = gifData.images.original.url;
    
          // Check if the URL is valid
          try {
            await axios.head(gifUrl);
            validGifUrls.push(gifUrl);
          } catch (error) {
            console.error('Invalid URL:', gifUrl);
          }
        }));
    
        setGifUrls(validGifUrls);
    
        const initialIndexes = Array.from({ length: validGifUrls.length }, (_, index) => index);
        setCurrentGifIndexes(initialIndexes.sort(() => Math.random() - 0.5));
      } catch (error) {
        console.error('Error fetching Giphy data:', error);
      }
    };    

    fetchRandomGifs();
  }, []);


  useEffect(() => {
    let countdownInterval;
  
    if (isLoading) {
      countdownInterval = setInterval(() => {
        setCountdown((prevCount) => {
          // Increase countdown until it reaches 100
          if (prevCount < 100) {
            return prevCount + 1;
          } else {
            // Stop the interval when countdown reaches 100
            clearInterval(countdownInterval);
            setIsLoading(false);
            // Redirect to another page when countdown reaches 100
            window.location.href = '/404';
            return prevCount;
          }
        });
      }, 1000);
    }
  
    // Clear the interval when the component unmounts or isLoading changes
    return () => {
      clearInterval(countdownInterval);
    };
  }, [isLoading]);
  

 const handleButtonClick = () => {
    setIsLoading(true);
  };

  return (
    <AppWrapper>
    <div style={containerStyle}>
      {currentGifIndexes.map((index, i) => (
        <div
          key={i}
          style={{
            ...gifStyle,
            backgroundImage: `url(${gifUrls[index]})`,
          }}
        />
      ))}
      <div style={contentStyle}>
      {isLoading ? (
        <Loader  countdown={countdown}/>
      ) : (
        <StyledButton onClick={handleButtonClick}>
          Spauskite čia! 🎄🎁
        </StyledButton>
      )}
      </div>
    </div>
    </AppWrapper>
  );
};

export default Home;