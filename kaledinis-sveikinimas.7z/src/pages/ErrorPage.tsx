import React from 'react'
import styled from 'styled-components';

const AppWrapper = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100vh;
`;

const StyledH1 = styled.h1`
    font-size: 200px;
    margin: 0;
`;

const StyledH3 = styled.h3`
    font-size: 36px;
    margin: 0;
`;

const StyledParagraph = styled.p`
    font-size: 18px;
    margin: 0;
`;

const ErrorPage = () => {
  return (
    <AppWrapper>
     <StyledH1>404</StyledH1>
      <StyledH3>Sveikinimas nerastas</StyledH3>
      <StyledParagraph>The resource requested could not be found on this server</StyledParagraph>
  </AppWrapper>
  )
}

export default ErrorPage;